
# MyLI-FSKM

Sistem Pengurusan Latihan Industri Fakulti Sains Komputer dan Matematik menggunakan Streamlit.

## Cara Jalankan Sistem

1. Install pakej:
```
pip install -r requirements.txt
```

2. Jalankan aplikasi:
```
streamlit run app.py
```

## Log Masuk Contoh
- Pelajar: `S12345` | `ali123`
- Pensyarah: `P67890` | `dr123`
- Admin: `A11111` | `admin123`
